

This is a simple command-line tool to evaluate the strength of a password based on:
- Length
- Numbers
- Uppercase letters
- Lowercase letters
- Special characters

