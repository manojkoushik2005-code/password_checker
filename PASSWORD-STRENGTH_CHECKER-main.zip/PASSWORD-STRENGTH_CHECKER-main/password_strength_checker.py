import re

def check_password_strength(password):
    strength = 0
    remarks = ""

    if len(password) >= 8:
        strength += 1
    else:
        remarks += "Password should be at least 8 characters long.\n"

    if re.search(r"\d", password):
        strength += 1
    else:
        remarks += "Password should contain at least one digit.\n"

    if re.search(r"[A-Z]", password):
        strength += 1
    else:
        remarks += "Password should contain at least one uppercase letter.\n"

    if re.search(r"[a-z]", password):
        strength += 1
    else:
        remarks += "Password should contain at least one lowercase letter.\n"

    if re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        strength += 1
    else:
        remarks += "Password should contain at least one special character (!@#$...).\n"

    if strength == 5:
        level = "Strong"
    elif 3 <= strength < 5:
        level = "Moderate"
    else:
        level = "Weak"

    return level, remarks

def main():
    print("🔐 Password Strength Checker 🔐")
    password = input("Enter your password: ")
    level, feedback = check_password_strength(password)

    print(f"\nPassword Strength: {level}")
    if feedback:
        print("Suggestions to improve:")
        print(feedback)

if __name__ == "__main__":
    main()
